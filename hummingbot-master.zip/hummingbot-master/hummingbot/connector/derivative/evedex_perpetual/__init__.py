"""Evedex Perpetual connector module."""
