"""hbot subcommands."""
